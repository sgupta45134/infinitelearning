<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   local_custom_events
 * @copyright  Sudhanshu Gupta<sudhanshug5@gmail.com>
 */
//defined('MOODLE_INTERNAL') || die();
require_once(dirname(__FILE__) . '/../../config.php');

function user_loggedin(\core\event\user_loggedin $event) {
    global $DB, $CFG, $USER;
    $extratime = 10 * 365 * 24 * 60 * 60;
    $eventdata = $event->get_data();
    $userid = $eventdata['objectid'];
    $user = get_complete_user_data('id', $userid);
    $domain = ".herovired.com";
    // $sameuser = $USER->id == $userid;
    $username = isset($user->username) ? $user->username : 'Not Determined';
    setcookie('vlearn_username', $username, time() + $extratime, '/', $domain);
    $email = isset($user->email) ? $user->email : 'Not Determined';
    setcookie('vlearn_email', $email, time() + $extratime, '/', $domain);
    $phone_number = isset($user->phone1) ? $user->phone1 : 0000000;
    setcookie('vlearn_mobile_number', $phone_number, time() + $extratime, '/', $domain);

    $records = $DB->get_records('herovired_sessions', array('userid' => $user->id, 'login_source' => 'web'));
    //$sessions_herovired = array();
    if (!empty($records)) {
        foreach ($records as $recordskey => $recordvalue) {
            $DB->delete_records_select('sessions', "sid='" . $recordvalue->sid . "'");
            $DB->delete_records_select('herovired_sessions', "sid='" . $sessionKey . "'");
        }
    }

    $data = new stdClass();
    $data->userid = $event->userid;
    $data->sid = session_id();
    $data->login_source = 'web';
    $data->time = time();
    $DB->insert_record('herovired_sessions', $data);
    $phone_number = isset($user->phone1) ? "+91" . substr($user->phone1, -10) : 0000000;

    //code wriiten by parul for herovired upshot profile update through API 
    require_once("$CFG->dirroot/local/custom_events/upshot_config.php");
    $filter = array(
        'key' => 'appuid',
        'value' => $phone_number,
        'operator' => 'eq',
    );
    $profile = array(
        'platform' => 'Desktop web',
        'firstName' => $user->firstname,
        'lastName' => $user->lastname,
        'email' => $user->email,
        'phone' => $phone_number,
        'Name' => $user->firstname . " " . $user->lastname,
    );
    $other = array(
        'source' => 'Vlearn',
        'UserType' => $user->profile['accesstype'],
        'UID' => $phone_number
    );

    $update = array('profile' => $profile, 'others' => $other);
    $auth = array(
        'appId' => $herovire_appId,
        'accountId' => $herovire_accountId,
        'apiKey' => $herovire_apiKey,
    );
    $data = array('filter' => $filter, 'updateSet' => $update, 'auth' => $auth);
    $json_data = json_encode($data);
    $url = "https://eapi.in.goupshot.com/v1/userprofile/add";
    try {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            "Content-Type:application/json",
            "Content-Length:" . strlen($json_data)
        ));
        $json_response = curl_exec($curl);
        curl_close($curl);
    } catch (Exception $ex) {
        curl_close($curl);
    }
    // }
    // SAML Cookie configuration 
    $samlpath = '/var/simplesamlphp/lib/_autoload.php';

    if (file_exists($samlpath)) {
        require_once($samlpath);
        $sspConfig = SimpleSAML\Configuration::getInstance();
        $sspAuthsources = SimpleSAML\Configuration::getConfig('authsources.php');
        $cookieName = $sspAuthsources->getValue("moodle-userpass");
        $uid = $eventdata['objectid']; //print_object($event);die;
        if ($cookieName && isset($cookieName['cookie_name']) && $cookieName['cookie_name']) {
            $salt = $sspConfig->getValue('secretsalt');
            setcookie($cookieName['cookie_name'], hash_hmac('sha1', $salt . $uid, $salt) . ':' . $uid, 0, $sspConfig->getValue('session.cookie.path'));
        }
    }
}

function user_enrolled_event(\core\event\user_enrolment_created $event) {
    global $DB, $CFG, $USER;
    $eventdata = $event->get_data();
    $userid = $eventdata['relateduserid'];
    $courseid = $eventdata['courseid'];
    // $myfile = fopen("$CFG->dirroot/local/custom/newfile.txt", "w") or die("Unable to open file!");
    // $enrol_user_details = $DB->get_record('user', array('id' => $userid));
    // $profile_fields = profile_user_record($userid, false);
    //   if($profile_fields->accesstype == "Premium"){
    //     $phone_number = isset($enrol_user_details->phone1) ? "+91".substr($enrol_user_details->phone1,-10) : 0000000;
    //     require_once("$CFG->dirroot/local/custom/lib.php");
    //     require_once("$CFG->dirroot/local/custom_events/upshot_config.php");
    //     $filter = array(
    //       'key' => 'appuid',
    //       'value' => $phone_number,
    //       'operator' => 'eq',
    //     );
    //     $profile =array(
    //       'platform'=>'Desktop web',
    //       'firstName' => $enrol_user_details->firstname,
    //       'lastName'=>$enrol_user_details->lastname,
    //       'email' => $enrol_user_details->email,
    //       'phone' => $phone_number,
    //       'Name'=>$enrol_user_details->firstname." ".$uenrol_user_detailsser->lastname,
    //     );
    //     $other=array(
    //       'source'=> 'Vlearn',
    //       'UserType'=>$enrol_user_details->profile['accesstype'],
    //       'UID'=>$phone_number
    //     );
    //     $update = array('profile'=>$profile,'others'=> $other);
    //     $auth = array(
    //       'appId' => $appId,
    //       'accountId' => $accountId,
    //       'apiKey' => $apiKey,
    //     );
    //     $data = array('filter'=>$filter,'updateSet'=>$update,'auth'=>$auth);
    //     $json_data = json_encode($data); 
    //     $url = "https://eapi.in.goupshot.com/v1/userprofile/add";
    //       try
    //       {
    //           $curl = curl_init($url);
    //           curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    //           curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //           curl_setopt($curl, CURLOPT_HEADER, 0);
    //           curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
    //           curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    //           curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    //                   "Content-Type:application/json",
    //                   "Content-Length:".strlen($json_data)
    //                   ));
    //           $json_response = curl_exec($curl);
    //           curl_close($curl);     
    //       } catch (Exception $ex) { 
    //           curl_close($curl);
    //       }
    //     $program_name = return_course_program_name($courseid);
    //     $timespent_format = convert_seconds();
    //     $course_details = $DB->get_record('course',array('id'=> $courseid));
    //     $customdata = array(
    //       'firstname'=>$enrol_user_details->firstname,
    //       'lastname'=>$enrol_user_details->lastname,
    //       'username'=>$enrol_user_details->username,
    //       'email'=> $enrol_user_details->email,
    //       'MobileNumber'=>$phone_number,
    //       'city'=>$enrol_user_details->city,
    //       'state'=> $profile_fields->state,
    //       'country'=> $enrol_user_details->country,
    //       'latest_program_name' => $program_name,
    //       'Course Name'=> $course_details->fullname,
    //       'User Access type' => $profile_fields->accesstype,
    //     );
    //     $data = array(
    //       'eventId' => rand(),
    //       'appuid' => $phone_number,
    //       'userId' => $phone_number,
    //       'eventName' => "Student_enrolled_program",
    //       'platform'=>'Desktop Web',
    //       'sessionId'=>rand(),
    //       'eventAttributes'=> $customdata,
    //       'startTime'=>time(),
    //       'endTime'=>time(),
    //       'tzoffset'=>"+19800000"
    //     );
    //     $auth = array(
    //       'appId' => $appId,
    //       'accountId' => $accountId,
    //       'apiKey' => $apiKey,
    //     );
    //     $content = array('data'=>$data,'auth'=>$auth);
    //     $json_data = json_encode($content); 
    //     $url = "https://eapi.in.goupshot.com/v1/events/add";
    //     try
    //     {
    //         $curl = curl_init($url);
    //         curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    //         curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //         curl_setopt($curl, CURLOPT_HEADER, 0);
    //         curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
    //         curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    //         curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    //                 "Content-Type:application/json",
    //                 "Content-Length:".strlen($json_data)
    //                 ));
    //         $json_response = curl_exec($curl);
    //         // print_object($json_response);
    //         curl_close($curl);     
    //     } catch (Exception $ex) { 
    //         curl_close($curl);
    //     }
    //   }
    // fwrite($myfile, "$json_data");
    // fclose($myfile);
}

function user_created_event(\core\event\user_created $event) {
    global $DB, $CFG, $USER;
    $eventdata = $event->get_data();
    $user_details = $DB->get_record('user', array('id' => $eventdata['relateduserid']));
    $profile_fields = profile_user_record($eventdata['relateduserid'], false);
    if ($profile_fields->accesstype == "Premium") {
        require_once("$CFG->dirroot/local/custom_events/upshot_config.php");
        $phone_number = isset($user_details->phone1) ? "+91" . substr($user_details->phone1, -10) : 0000000;
        $filter = array(
            'key' => 'appuid',
            'value' => $phone_number,
            'operator' => 'eq',
        );
        $profile = array(
            'platform' => 'Desktop web',
            'firstName' => $user_details->firstname,
            'lastName' => $user_details->lastname,
            'email' => $user_details->email,
            'phone' => $phone_number,
            'Name' => $user_details->firstname . " " . $user_details->lastname,
        );
        $other = array(
            'source' => 'Vlearn',
            'UserType' => $profile_fields->accesstype,
            'UID' => $phone_number
        );

        $update = array('profile' => $profile, 'others' => $other);
        $auth = array(
            'appId' => $appId,
            'accountId' => $accountId,
            'apiKey' => $apiKey,
        );
        $data = array('filter' => $filter, 'updateSet' => $update, 'auth' => $auth);
        $json_data = json_encode($data);
        $url = "https://eapi.in.goupshot.com/v1/userprofile/add";
        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Content-Type:application/json",
                "Content-Length:" . strlen($json_data)
            ));
            $json_response = curl_exec($curl);
            curl_close($curl);
        } catch (Exception $ex) {
            curl_close($curl);
        }
    }
}

function user_updated_event(\core\event\user_updated $event) {
    global $DB, $CFG, $USER;
    $eventdata = $event->get_data();
    $user_details = $DB->get_record('user', array('id' => $eventdata['relateduserid']));
    $profile_fields = profile_user_record($eventdata['relateduserid'], false);
    if ($profile_fields->accesstype == "Premium") {
//        require_once("$CFG->dirroot/local/custom_events/upshot_config.php");
        $phone_number = isset($user_details->phone1) ? "+91" . substr($user_details->phone1, -10) : 0000000;
        $appuid = isset($user_details->phone1) ? "+91" . substr($user_details->phone1, -10) : $USER->id;
//        $filter = array(
//            'key' => 'appuid',
//            'value' => $phone_number,
//            'operator' => 'eq',
//        );
//        $profile = array(
//            'platform' => 'Desktop web',
//            'firstName' => $user_details->firstname,
//            'lastName' => $user_details->lastname,
//            'email' => $user_details->email,
//            'phone' => $phone_number,
//            'Name' => $user_details->firstname . " " . $user_details->lastname,
//        );
//        $other = array(
//            'source' => 'Vlearn',
//            'UserType' => $profile_fields->accesstype,
//            'UID' => $phone_number
//        );
//
//        $update = array('profile' => $profile, 'others' => $other);
//        $auth = array(
//            'appId' => $appId,
//            'accountId' => $accountId,
//            'apiKey' => $apiKey,
//        );
//        $data = array('filter' => $filter, 'updateSet' => $update, 'auth' => $auth);
//        $json_data = json_encode($data);
//        $url = "https://eapi.in.goupshot.com/v1/userprofile/add";
//        try {
//            $curl = curl_init($url);
//            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
//            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
//            curl_setopt($curl, CURLOPT_HEADER, 0);
//            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
//            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
//            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
//                "Content-Type:application/json",
//                "Content-Length:" . strlen($json_data)
//            ));
//            $json_response = curl_exec($curl);
//            print_object($json_response);
//            curl_close($curl);
//        } catch (Exception $ex) {
//            curl_close($curl);
//        }
        
        
        $data = array(
        "appuid" => $appuid,
        "firstName" => $user_details->firstname,
        "lastName" => $user_details->lastname,
        "email" => $user_details->email,
        "phone" => $phone_number,
        "userAccessType"=> "Premium",
        "source"=> "Vlearn"
        );

        $json_data = json_encode($data);
        $url = "https://staging-api.herovired.com/event-manager/events/v1/profile/update";
        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Content-Type:application/json",
            ));
            $json_response = curl_exec($curl);
            curl_close($curl);
        } catch (Exception $ex) {
            curl_close($curl);
        }
    }
}

function update_last_access_activity(core\event\course_module_viewed $event) {
    global $DB, $CFG, $USER;
    $eventdata = $event->get_data();
    $courseid = $eventdata['courseid'];
    $userid = $eventdata['userid'];
    $cm_id = $eventdata['contextinstanceid'];
    $cm = $DB->get_record('course_modules', array('id' => $cm_id));
    $error = 'success';
    $data_error = '';
    try {
        if ($cm) {
            /** Verify if the user already has a record of the activities viewed */
            if ($cm_view = $DB->get_record('course_modules_view', ['course_id' => $courseid, 'user_id' => $userid])) {
                $cm_view_update = new stdClass();
                $cm_view_update->id = $cm_view->id;
                $cm_view_update->course_id = $courseid;
                $cm_view_update->cm_id = $cm_id;
                $cm_view_update->user_id = $userid;
                $DB->update_record('course_modules_view', $cm_view_update);
            } else {
                /** If not, insert a new record, else update the current one */
                $cm_view = new stdClass();
                $cm_view->course_id = $courseid;
                $cm_view->cm_id = $cm_id;
                $cm_view->user_id = $userid;
                $DB->insert_record('course_modules_view', $cm_view);
            }
        }
    } catch (Exception $e) {
        $error = 'error';
        $data_error = 'Caught exception: ' . $e->getMessage() . "\n";
    }
}

function module_created(\core\event\course_module_created $event) {
    global $DB, $USER, $CFG;
    $act_array = array('quiz', 'feedback', 'assign', 'doselect', 'zoom');

    $modulename = $event->other['modulename'];
    if (in_array($modulename, $act_array)) {
        /**
         * Add Custom api for vassist event on quiz add
         * @added by Sudhanshu Gupta
         * @added on 03-08-2022
         * @herovired
         */
        $phone_number = isset($USER->phone1) ? "+91" . substr($USER->phone1, -10) : $USER->id;
        $eventname = $modulename . "_created";
        $course_details = get_course($event->courseid);
        $activityid = $event->other['instanceid'];
        $url = $CFG->wwwroot . "/mod/$modulename/view.php?id=" . $event->objectid;
        $start = "";
        $end = "";

        switch ($modulename) {
            case 'zoom':
                $zoom = $DB->get_record('zoom', array('id' => $activityid));
                $start = $zoom->start_time ? $zoom->start_time : "";
                $end = $zoom->duration ? $zoom->duration : "";
                $activityname = $zoom->name;
                $eventname = "online_class_scheduled";
                break;
            case 'assign':
                $assign = $DB->get_record('assign', array('id' => $activityid));
                $start = $assign->allowsubmissionsfromdate ? $assign->allowsubmissionsfromdate : "";
                $end = $assign->duedate ? $assign->duedate : "";
                $activityname = $assign->name;
                $eventname = "assignment_created";
                break;
            case 'quiz':
                $quiz = $DB->get_record('quiz', array('id' => $activityid));
                $start = $quiz->timeopen ? $quiz->timeopen : "";
                $end = $quiz->timeclose ? $quiz->timeclose : "";
                $activityname = $quiz->name;
                $eventname = "quiz_created";
                break;
            case 'doselect':
                $doselect = $DB->get_record('doselect', array('id' => $activityid));
                $start = $doselect->starttime ? $doselect->starttime : "";
                $end = $doselect->endtime ? $doselect->endtime : "";
                $activityname = $doselect->name;
                $eventname = "doselect_quiz_created";
                break;
            case 'feedback':
                $feedback = $DB->get_record('feedback', array('id' => $activityid));
                $start = $feedback->timeopen ? $feedback->timeopen : "";
                $end = $feedback->timeclose ? $feedback->timeclose : "";
                $activityname = $feedback->name;
                $eventname = "feedback_created";
                break;
                exit;
        }



        $data = array(
            "appuid" => $phone_number,
            "eventName" => $eventname,
            "source" => "Vlearn",
            "activityId" => $activityid,
            "activityUrl" => $url,
            "courseName" => $course_details->fullname,
            "courseId" => $event->courseid,
            "startDateTime" => $start,
        );

        switch ($modulename) {
            case 'zoom':
                $data["className"] = $activityname;
                $data["duration"] = $end;
                break;
            case 'assign':
                $data["assignmentName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'quiz':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'doselect':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'feedback':
                $data["feedbackName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
                exit;
        }

        $json_data = json_encode($data);
        $url = "https://staging-api.herovired.com/event-manager/events/v1/activity";
        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Content-Type:application/json",
            ));
            $json_response = curl_exec($curl);
            curl_close($curl);
        } catch (Exception $ex) {
            curl_close($curl);
        }
    }
    //end of code for trigger events to vassist
}

function module_updated(\core\event\course_module_updated $event) {
    global $DB, $USER, $CFG;
    $act_array = array('quiz', 'feedback', 'assign', 'doselect', 'zoom');

    $modulename = $event->other['modulename'];
    if (in_array($modulename, $act_array)) {
        /**
         * Add Custom api for vassist event on quiz add
         * @added by Sudhanshu Gupta
         * @added on 03-08-2022
         * @herovired
         */
        $phone_number = isset($USER->phone1) ? "+91" . substr($USER->phone1, -10) : $USER->id;
        $eventname = $modulename . "_created";
        $course_details = get_course($event->courseid);
        $activityid = $event->other['instanceid'];
        $url = $CFG->wwwroot . "/mod/$modulename/view.php?id=" . $event->objectid;
        $start = "";
        $end = "";

        switch ($modulename) {
            case 'zoom':
                $zoom = $DB->get_record('zoom', array('id' => $activityid));
                $start = $zoom->start_time ? $zoom->start_time : "";
                $end = $zoom->duration ? $zoom->duration : "";
                $activityname = $zoom->name;
                $eventname = "online_class_updated";
                break;
            case 'assign':
                $assign = $DB->get_record('assign', array('id' => $activityid));
                $start = $assign->allowsubmissionsfromdate ? $assign->allowsubmissionsfromdate : "";
                $end = $assign->duedate ? $assign->duedate : "";
                $activityname = $assign->name;
                $eventname = "assignment_updated";
                break;
            case 'quiz':
                $quiz = $DB->get_record('quiz', array('id' => $activityid));
                $start = $quiz->timeopen ? $quiz->timeopen : "";
                $end = $quiz->timeclose ? $quiz->timeclose : "";
                $activityname = $quiz->name;
                $eventname = "quiz_updated";
                break;
            case 'doselect':
                $doselect = $DB->get_record('doselect', array('id' => $activityid));
                $start = $doselect->starttime ? $doselect->starttime : "";
                $end = $doselect->endtime ? $doselect->endtime : "";
                $activityname = $doselect->name;
                $eventname = "doselect_quiz_updated";
                break;
            case 'feedback':
                $feedback = $DB->get_record('feedback', array('id' => $activityid));
                $start = $feedback->timeopen ? $feedback->timeopen : "";
                $end = $feedback->timeclose ? $feedback->timeclose : "";
                $activityname = $feedback->name;
                $eventname = "feedback_updated";
                break;
                exit;
        }



        $data = array(
            "appuid" => $phone_number,
            "eventName" => $eventname,
            "source" => "Vlearn",
            "activityId" => $activityid,
            "activityUrl" => $url,
            "courseName" => $course_details->fullname,
            "courseId" => $event->courseid,
            "startDateTime" => $start,
        );

        switch ($modulename) {
            case 'zoom':
                $data["className"] = $activityname;
                $data["duration"] = $end;
                break;
            case 'assign':
                $data["assignmentName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'quiz':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'doselect':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'feedback':
                $data["feedbackName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
                exit;
        }

        $json_data = json_encode($data);
        $url = "https://staging-api.herovired.com/event-manager/events/v1/activity";
        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Content-Type:application/json",
            ));
            $json_response = curl_exec($curl);
            curl_close($curl);
        } catch (Exception $ex) {
            curl_close($curl);
        }
    }
}


function module_deleted(\core\event\course_module_deleted $event) {
    global $DB, $USER, $CFG;
    $act_array = array('quiz', 'feedback', 'assign', 'doselect', 'zoom');

    $modulename = $event->other['modulename'];
    if (in_array($modulename, $act_array)) {
        /**
         * Add Custom api for vassist event on quiz add
         * @added by Sudhanshu Gupta
         * @added on 03-08-2022
         * @herovired
         */
        $phone_number = isset($USER->phone1) ? "+91" . substr($USER->phone1, -10) : $USER->id;
        $eventname = $modulename . "_created";
        $course_details = get_course($event->courseid);
        $activityid = $event->other['instanceid'];
        $url = $CFG->wwwroot . "/mod/$modulename/view.php?id=" . $event->objectid;
        $start = "";
        $end = "";

        switch ($modulename) {
            case 'zoom':
                $zoom = $DB->get_record('zoom', array('id' => $activityid));
                $start = $zoom->start_time ? $zoom->start_time : "";
                $end = $zoom->duration ? $zoom->duration : "";
                $activityname = $zoom->name;
                $eventname = "online_class_deleted";
                break;
            case 'assign':
                $assign = $DB->get_record('assign', array('id' => $activityid));
                $start = $assign->allowsubmissionsfromdate ? $assign->allowsubmissionsfromdate : "";
                $end = $assign->duedate ? $assign->duedate : "";
                $activityname = $assign->name;
                $eventname = "assignment_deleted";
                break;
            case 'quiz':
                $quiz = $DB->get_record('quiz', array('id' => $activityid));
                $start = $quiz->timeopen ? $quiz->timeopen : "";
                $end = $quiz->timeclose ? $quiz->timeclose : "";
                $activityname = $quiz->name;
                $eventname = "quiz_deleted";
                break;
            case 'doselect':
                $doselect = $DB->get_record('doselect', array('id' => $activityid));
                $start = $doselect->starttime ? $doselect->starttime : "";
                $end = $doselect->endtime ? $doselect->endtime : "";
                $activityname = $doselect->name;
                $eventname = "doselect_quiz_deleted";
                break;
            case 'feedback':
                $feedback = $DB->get_record('feedback', array('id' => $activityid));
                $start = $feedback->timeopen ? $feedback->timeopen : "";
                $end = $feedback->timeclose ? $feedback->timeclose : "";
                $activityname = $feedback->name;
                $eventname = "feedback_deleted";
                break;
                exit;
        }



        $data = array(
            "appuid" => $phone_number,
            "eventName" => $eventname,
            "source" => "Vlearn",
            "activityId" => $activityid,
            "activityUrl" => $url,
            "courseName" => $course_details->fullname,
            "courseId" => $event->courseid,
            "startDateTime" => $start,
        );

        switch ($modulename) {
            case 'zoom':
                $data["className"] = $activityname;
                $data["duration"] = $end;
                break;
            case 'assign':
                $data["assignmentName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'quiz':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'doselect':
                $data["quizName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
            case 'feedback':
                $data["feedbackName"] = $activityname;
                $data["endDateTime"] = $end;
                break;
                exit;
        }
        print_object($data);die;
        $json_data = json_encode($data);
        $url = "https://staging-api.herovired.com/event-manager/events/v1/activity";
        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                "Content-Type:application/json",
            ));
            $json_response = curl_exec($curl);
            curl_close($curl);
        } catch (Exception $ex) {
            curl_close($curl);
        }
    }
}

//end
?>
